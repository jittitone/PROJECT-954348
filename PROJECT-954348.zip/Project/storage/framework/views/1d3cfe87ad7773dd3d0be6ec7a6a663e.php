<?php $__env->startSection('content'); ?>
    <html>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/food-list.css')); ?>" />
    </head>
    <main>

        <body>
            <div class="container">
                <h1>Add New Food</h1>

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('foods.updateNew', ['food' => $food->id,])); ?>" method="POST" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Food Name:</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($food->name); ?>"
                            required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea name="description" id="description" class="form-control"><?php echo e($food->description); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="ingrient">Ingredients:</label>
                        <input type="text" name="ingredient" id="ingredient" class="form-control"
                            value="<?php echo e($food->ingredient); ?>">
                    </div>
                    <div class="form-group">
                        <label for="time">Stepfood:</label>
                        <textarea name="description" id="description" class="form-control"><?php echo e($food->description); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="time">Preparation Time:</label>
                        <input type="text" name="time" id="time" class="form-control"
                            value="<?php echo e($food->time); ?>"> <label for="">นาที</label>
                    </div>
                    <div>
                        
                        label>Categories
                        <select value="category_id" name="category_id">
                            <option value="<?php echo e($food->category_id); ?>"> <?php echo e($food->category->name); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->id != $food->category->id): ?>
                                    <option value="<?php echo e($category->id); ?>">
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </label><br />
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="img">Current Image:</label><br>
                        <?php if($food->img): ?>
                            <img src="<?php echo e(asset('images/' . $food->img)); ?>" alt="Current Food Image" width="150" class="mb-2">
                        <?php else: ?>
                            <p>No image available</p>
                        <?php endif; ?>
                    </div>
                    

                    <div class="form-group">
                        <label for="img">Upload New Image:</label>
                        <input type="file" name="img" id="img" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/foods/update.blade.php ENDPATH**/ ?>