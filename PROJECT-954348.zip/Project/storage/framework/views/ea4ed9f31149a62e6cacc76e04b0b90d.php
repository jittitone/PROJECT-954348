<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login.css')); ?>" />
 
</head>

<body>   
    <div class="title"><h1>DISH DEELIGHT</h1></div>
    <div class="container">
        <div class="left"></div>
        <div class="right">

            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>


            <div class="formBox">
                <form action="<?php echo e(route('authenticate')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <p>
                        E-mail <input type="text" name="email" placeholder="E-mail" required />
                    </p>
                    <p>
                        Password <input type="password" name="password" placeholder="password" required />
                    </p>

                    <div class="register"><a href="<?php echo e(route('register')); ?>">Register</a></div>

                    <button type="submit">Login</button>
                    <?php $__errorArgs = ['credentials'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="warn"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
            </div>
            
        </div>

    </div>
    </form>
</body>

</html><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/logins/form.blade.php ENDPATH**/ ?>