<?php $__env->startSection('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/food-list.css')); ?>" />
</head>

<main>
<body>
    <?php echo csrf_field(); ?>
    <form action="" method="post">
<div class="container">
    <div class="title-wrapper">
        <div class="title">
            <h2>รายการอาหาร</h2>
        </div>
    </div>

    <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div>
        <span><?php echo e($message); ?></span>
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if(session('success')): ?>
    <div class="success-message">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="top-bar">
        <div class="search-bar">
            <input type="text" placeholder="Search Foods ...">
        </div>
        <div class="create-button">
            <a href="<?php echo e(route('foods.create')); ?>">CREATE</a>
        </div>
    </div>
    
        <div class="data-container">
            <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <a class="linkfoods" href="<?php echo e(route('foods.view', $food->id)); ?>">
                    <div class="card">
                        <div class="imgwrap">
                            <img src="<?php echo e(asset('images/' . $food->img)); ?>" alt="">
                        </div>
                        <h2><?php echo e($food->name); ?></h2>
                        <p><?php echo e($food->description); ?></p>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </form>
</body>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/foods/list.blade.php ENDPATH**/ ?>