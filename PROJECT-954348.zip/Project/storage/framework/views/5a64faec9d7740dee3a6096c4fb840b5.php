<?php $__env->startSection('content'); ?>
    <html>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/form.css')); ?>" />
    </head>
    <main>
       
        <body>
            <div class="container">
                <div class="title">Add New Food</div>
                
            
                <form action="<?php echo e(route('foods.createAdd')); ?>" method="POST" enctype="multipart/form-data">
                    <?php if(session('error')): ?>
                    <div class="error-message">
                        <p><?php echo e(session('error')); ?></p>
                    </div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <div class="user-details">
                        <div class="input-box">
                            <span class="user-details">Food Name:</span>
                            <input type="text" name="name" placeholder="Enter Here" required>
                        </div>

                        <div class="input-box">
                            <span class="user-details">Description:</span>
                            <textarea name="description" placeholder="Enter Here"></textarea>
                        </div>

                        <div class="input-box">
                            <span class="user-details">Ingredients:</span>
                            <input type="text" name="ingredient" placeholder="Enter Here">
                        </div>
                        <div class="input-box">
                            <span class="user-details">Stepfood:</span>
                            <textarea name="stepfood" placeholder="Enter Here"></textarea>
                        </div>

                        <div class="input-box">
                            <span class="user-details">Preparation Time:(นาที)</span>
                            <input type="text" name="time" placeholder="Enter Here">
                        </div>

                        <div class="select-container">
                            
                            <select class="select-box" name="category_id">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="select-container">
                            <span>Image:</span>
                            <input type="file" name="img" placeholder="Enter Here">
                        </div>
                    </div>
                    <div class="button">
                        <input type="submit" value="Create">
                    </div>
                </form>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/foods/create.blade.php ENDPATH**/ ?>