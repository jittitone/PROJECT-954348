<?php $__env->startSection('content'); ?>
<html>
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
</head>
    
<main>

    <body>
        <div class="container">
            <div class="title">Review</div>

            <form action="<?php echo e(route('reviews.store', ['food_id' => $food->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="user-details">
                    <div class="input-box">
                        <span class="user-details">Rating:</span>
                        <textarea name="comment" placeholder="Write your review..." required></textarea>
                    </div>
                    <div class="select-container">
                        <select name="star" required>
                            <option value="" disabled selected>Select a rating</option>
                            <option value="1">1 Star</option>
                            <option value="2">2 Stars</option>
                            <option value="3">3 Stars</option>
                            <option value="4">4 Stars</option>
                            <option value="5">5 Stars</option>
                        </select>
                    </div>
                    <div class="button">
                        <input type="submit" value="Submit Review">
                    </div>
                </div>
            </form>
        </div>
    </body>
</main>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/review/form_create.blade.php ENDPATH**/ ?>