<?php $__env->startSection('content'); ?>
    <html>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/form.css')); ?>" />
    </head>
    <main>

        <body>
            <div class="container">
                <div class="title">Update profile</div>

                <?php if(session('success')): ?>
                    <div class="success-message">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="error-message">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('users.updateSelf', ['user' => $user->id])); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="user-details">
                        <div class="input-box">
                            <label class="user-details">Name:</label>
                            <input type="text" name="name" id="name" value="<?php echo e($user->name); ?>" required>
                        </div>

                        <div class="input-box">
                            <label class="user-details">E-mail:</label>
                            <input type="email" name="email" id="email" value="<?php echo e($user->email); ?>" required>
                        </div>

                        <div class="input-box">
                            <label class="user-details">Profile:</label>
                            <textarea name="profile" id="profile" cols="30" rows="10" ><?php echo e($user->profile); ?></textarea>
                        </div>

                        <div class="input-box">
                            <label class="user-details">Password:</label>
                            <input type="password" name="password" id="password" placeholder="Leave empty to keep current password">
                            <small class="text-muted">Leave empty if you don't want to change the password</small>
                        </div>
                    </div>
                    <div class="button">
                    <input type="submit" value="Update Profile">
                </div>
            </div>
                </form>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/users/self.blade.php ENDPATH**/ ?>