<?php $__env->startSection('content'); ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/control.css')); ?>" />
    </head>

    <body>
            <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <span><?php echo e($message); ?></span>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            

            <main class="table">
            <form action="" method="post">
                <section class="table-header">
                    
                    <h1>Edit</h1>
                    <?php if(session('success')): ?>
                    <div class="success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="create-button">
                    <a href="<?php echo e(route('foods.create')); ?>">CREATE</a>
                </div>
                </section>
                <section class="table-body">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Food's Name</th>
                                    <th>Description</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($food->id); ?></td>
                                        <td><?php echo e($food->name); ?></td>
                                        <td><?php echo e($food->description); ?></td>
                                        <td class="update-button"><a href="<?php echo e(route('foods.update-form', ['food' => $food->id])); ?>">Update</a></td>
                                        <td class="delete-button"><a href="<?php echo e(route('foods.delete-form', ['food' => $food->id])); ?>">Delete</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                        </table>
                </section>
        </main>
    </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/foods/control.blade.php ENDPATH**/ ?>