<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/home.css')); ?>" />
<body>
    <form action="" method="post">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="title-wrapper">
            <div class="title">
                <h2>DISHDELIGHT</h2>
                <h2>DISHDELIGHT</h2>
            </div>
        </div>
        <div class="photo-gallery">

            <div class="column">
                <div class="photo">
                    <img src="<?php echo e(asset('img/10.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/5.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/11.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/6.webp')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/13.jpg')); ?>" alt="">
                </div>
            </div>

            <div class="column">
                <div class="photo">
                    <img src="<?php echo e(asset('img/3.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/4.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/12.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/9.webp')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/15.jpeg')); ?>" alt="">
                </div>
            </div>

            <div class="column">
                <div class="photo">
                    <img src="<?php echo e(asset('img/7.webp')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/8.webp')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/1.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/13.jpg')); ?>" alt="">
                </div>
                <div class="photo">
                    <img src="<?php echo e(asset('img/14.jpg')); ?>" alt="">
                </div>
            </div>


        </div>
    </form>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/home/form.blade.php ENDPATH**/ ?>