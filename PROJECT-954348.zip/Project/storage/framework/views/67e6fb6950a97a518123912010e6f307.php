<?php $__env->startSection('content'); ?>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/comment.css')); ?>" />
</head>
<main>
<body>
    <?php echo csrf_field(); ?>
    <form action="" method="post">
    <div class="content">
      <div class="container">
        <div class="comment-container">
            <div class="comment-card">
                <h3 class="title">Title</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem, beatae ipsam vitae consequuntur eligendi deserunt quibusdam fuga sunt, 
                    soluta excepturi eveniet, porro commodi maiores fugit inventore quod? Magnam, dolorem necessitatibus!
                </p>
                <div class="comment-footer">
                    <div class="edit">Edit</div>
                    <div class="delete">Delete</div>
                </div>
            </div>
        </div>
        <div class="comment-container">
            <div class="comment-card">
                <h3 class="title">Title</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem, beatae ipsam vitae consequuntur eligendi deserunt quibusdam fuga sunt, 
                    soluta excepturi eveniet, porro commodi maiores fugit inventore quod? Magnam, dolorem necessitatibus!
                </p>
                <div class="comment-footer">
                    <div class="edit">Edit</div>
                    <div class="delete">Delete</div>
                </div>
            </div>
        </div>
        <div class="comment-container">
            <div class="comment-card">
                <h3 class="title">Title</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem, beatae ipsam vitae consequuntur eligendi deserunt quibusdam fuga sunt, 
                    soluta excepturi eveniet, porro commodi maiores fugit inventore quod? Magnam, dolorem necessitatibus!
                </p>
                <div class="comment-footer">
                    <div class="edit">Edit</div>
                    <div class="delete">Delete</div>
                </div>
            </div>
        </div>
        <div class="comment-container">
            <div class="comment-card">
                <h3 class="title">Title</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem, beatae ipsam vitae consequuntur eligendi deserunt quibusdam fuga sunt, 
                    soluta excepturi eveniet, porro commodi maiores fugit inventore quod? Magnam, dolorem necessitatibus!
                </p>
                <div class="comment-footer">
                    <div class="edit">Edit</div>
                    <div class="delete">Delete</div>
                </div>
            </div>
        </div>
        <div class="comment-container">
            <div class="comment-card">
                <h3 class="title">Title</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem, beatae ipsam vitae consequuntur eligendi deserunt quibusdam fuga sunt, 
                    soluta excepturi eveniet, porro commodi maiores fugit inventore quod? Magnam, dolorem necessitatibus!
                </p>
                <div class="comment-footer">
                    <div class="edit">Edit</div>
                    <div class="delete">Delete</div>
                </div>
            </div>
        </div>
      </div>
        <div class="commentbar-container">
            <input class="comment-input" type="text" placeholder="comment">
        </div>
    </div>
    </form>

</body>

</main>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/reviews/comment.blade.php ENDPATH**/ ?>