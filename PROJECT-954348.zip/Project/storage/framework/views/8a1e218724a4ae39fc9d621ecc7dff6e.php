<?php $__env->startSection('content'); ?>
    <html>

    <head>
        <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
    </head>
    <main>

        <body>
            <div class="container">
                <div class="title"> Edit Review</div>

                <form action="<?php echo e(route('reviews.update', $review->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> <!-- ใช้สำหรับ PUT Method -->
                    <div class="user-details">
                        <div class="input-box">
                            <span class="user-details">Rating:</span>
                            <textarea name="comment" placeholder="Write your review..."><?php echo e($review->comment); ?></textarea>
                        </div>
                        <div class="select-container">
                            <select name="star">
                                <option value="1" <?php echo e($review->star == 1 ? 'selected' : ''); ?>>1 Star</option>
                                <option value="2" <?php echo e($review->star == 2 ? 'selected' : ''); ?>>2 Stars</option>
                                <option value="3" <?php echo e($review->star == 3 ? 'selected' : ''); ?>>3 Stars</option>
                                <option value="4" <?php echo e($review->star == 4 ? 'selected' : ''); ?>>4 Stars</option>
                                <option value="5" <?php echo e($review->star == 5 ? 'selected' : ''); ?>>5 Stars</option>
                            </select>
                        </div>
                        <div class="button">
                            <input type="hidden" name="food_id" value="<?php echo e($review->food_id); ?>">
                            <input type="submit" value="Update Review">
                        </div>
                    </div>
                </form>
            </div>
        </body>
    </main>
    </html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/review/edit.blade.php ENDPATH**/ ?>