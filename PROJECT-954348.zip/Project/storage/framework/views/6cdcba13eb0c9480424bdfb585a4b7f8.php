<!DOCTYPE html>

<head>
    <title>Project <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>


<div class="main-container">
    <div class="side-nav">
        <div class="user">
            <a href="<?php echo e(Auth::check() ? route('users.self',Auth::user()->id) : route('login')); ?>">
                <img src="<?php echo e(Avatar::create(Auth::check() ? Auth::user()->name : 'view')->toBase64()); ?>" class="user-img" />
            </a>
            
         
           
            <div>
                <h2><?php echo e(Auth::check() ? Auth::user()->name : 'viewer'); ?></h2>
<p><?php echo e(Auth::check() ? Auth::user()->email : ''); ?></p>
            </div>
        </div>

        <ul>
            <li><img src="<?php echo e(asset('img/homes.png')); ?>"><p><a href="<?php echo e(route('home.form')); ?>">Home</a></p></li>
            <li><img src="<?php echo e(asset('img/about.png')); ?>"><p><a href="<?php echo e(route('home.about')); ?>">About Us</a></p></li>
            <li><img src="<?php echo e(asset('img/list.png')); ?>"><p><a href="<?php echo e(route('foods.list')); ?>">List</a></p></li>
            <li><img src="<?php echo e(asset('img/list.png')); ?>"><p><a href="<?php echo e(route('foods.control')); ?>">Food Control</a></p></li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create', \App\Models\Category::class)): ?>
            <li><img src="<?php echo e(asset('img/list.png')); ?>"><p><a href="<?php echo e(route('categories.control')); ?>">Category Control</a></p></li>   
                <?php endif; ?>
            <li>
                <img src="<?php echo e(asset('img/category.png')); ?>"><p>Categories</p>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><p><a href="<?php echo e(route('categories.list', $category->id)); ?>">- <?php echo e($category->name); ?></a></p></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>

            <a href="<?php echo e(route('logout')); ?>"><li><p>Logout</p></li></a>
        </ul>
    </div>

    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
</div>

<footer>
    <div class="footer-container">
        <div class="footer-row">
            <div class="col">
                <a href="" class="footer-logo">DISHDELIGHT</a>
                <p>" เราเชื่อว่าการทำอาหารควรเป็นเรื่องสนุกและเต็มไปด้วยความสุข เว็บไซต์ของเรารวบรวมสูตรอาหารหลากหลาย ทั้งเมนูคาว หวาน และเพื่อสุขภาพ ให้คุณได้ลองสร้างสรรค์มื้ออร่อยที่บ้านได้ง่ายๆ ทุกวัน มาร่วมเพลิดเพลินกับการทำอาหารที่ไม่ยุ่งยากไปกับเรา !! " </p>
                <ul class="social">
                    <li><a href=""><i class="fa-brands fa-facebook-f"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-twitter"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-instagram"></i></a></li>
                    <li><a href=""><i class="fa-brands fa-linkedin-in"></i></a></li>
                </ul>
            </div>
    </div>
</footer>

</body>

</html>
<?php /**PATH /Users/ill./Documents/954348/Project/resources/views/layouts/main.blade.php ENDPATH**/ ?>