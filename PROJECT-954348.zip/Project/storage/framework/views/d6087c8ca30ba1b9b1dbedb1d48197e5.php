<?php $__env->startSection('content'); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/food-view.css')); ?>" />
</head>

<main>
    <div class="row">
        <div class="imgwrap">
            <img src="<?php echo e(asset('images/' . $food->img)); ?>" alt="<?php echo e($food->name); ?>">
        </div>
        <div class="contentwrap">
            <div class="text-content">
                <h2><?php echo e($food->name); ?></h2>
                <h3>รายละเอียด</h3>
                <div class="scrollbox">
                    <div class="scrollbox-inner">
                        <span class="dis"><?php echo e($food->description); ?></span>
                        <div><h4>ส่วนประกอบ</h4></div>  
                        <div><?php echo nl2br(e($food->ingredient)); ?></div>
                        <div><h4>ขั้นตอนการทำ</h4></div>  
                        <div><?php echo nl2br(e($food->stepfood)); ?></div>
                        <div><h4>เวลาที่ใช้ในการปรุงอาหาร</h4></div>  
                        <div class="dis"><?php echo e($food->time); ?></div>
                        <div><h4>ผู้เขียนบทความ</h4></div>  
                        <div class="dis"><?php echo e($food->user->name); ?></div>
                        <div><h3>Rate Reviews <?php echo e($averageRating); ?></h3></div>
                        <a href="<?php echo e(route('reviews.create', ['food_id' => $food->id])); ?>">Write a Review</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if(session('success')): ?>
    <div class="success-message">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="error-message">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
    <div class="reviews">
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment-content">
            <div class="commentbig-container">
                <div class="comment-container">
                    <div class="comment-card">
                        <h3 class="titles"><?php echo e($review->user_name ?? 'Anonymous'); ?></h3>
                        <p><?php echo e($review->comment); ?></p>
                        <p>Rating: <?php echo e($review->star); ?> Stars</p>
                        <div class="comment-footer">
                            <?php if($review->user_id === Auth::id()): ?>
                                <div class="review-edit-button">
                                    <a href="<?php echo e(route('reviews.edit', $review->id)); ?>">Edit</a>
                                </div>
                                
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="review-delete-button">
                                        <a href="<?php echo e(route('reviews.destroy', $review->id)); ?>">Delete</a>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/foods/view.blade.php ENDPATH**/ ?>