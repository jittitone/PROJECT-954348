<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
</head>

<body>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <label>
            E-mail <input type="text" name="email" required />
        </label><br />
        <label>
            Password <input type="password" name="password" required />
        </label><br />
    </form>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/homes/form.blade.php ENDPATH**/ ?>