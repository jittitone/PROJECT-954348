<?php $__env->startSection('content'); ?>
    <html>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/form.css')); ?>" />
    </head>
    <main>

        <body>
            <div class="container">
                <div class="title">Update gategory</div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('categories.updateNew', ['category' => $category->id,])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="user-details">
                        <div class="input-box">
                        <label class="user-details">Category Name:</label>
                        <input type="text" name="name" id="name" value="<?php echo e($category->name); ?>" required>
                        </div>
                    </div>

                    <div class="button">
                        <input type="submit" value="Update">
                    </div>
                </form>
            </div>
        </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ill./Documents/954348/Project/resources/views/categories/update.blade.php ENDPATH**/ ?>